#include "capture.h"
#include "frame_queue.h"
#include "esp_wifi.h"
#include "esp_timer.h"
#include "esp_log.h"
#include <string.h>

static const char *TAG = "capture";

QueueHandle_t g_frame_q;

/* Common channels first so the dwell budget favours where the traffic is.
 * 2.4 GHz only here; add 5 GHz channels if your silicon + antenna support it. */
static const uint8_t channels[] = {1, 6, 11, 2, 7, 3, 8, 4, 9, 5, 10};
static volatile size_t hop_idx;
static esp_timer_handle_t hop_timer;
static volatile uint32_t drops;   /* frames lost to a full queue */

/* Runs in WiFi-task context (NOT an ISR). Must be fast and non-blocking:
 * copy a bounded prefix + rx metadata, enqueue with zero timeout, return.
 * Everything expensive (parse, dedup, signature eval, SD/LCD) is downstream. */
static void promisc_cb(void *buf, wifi_promiscuous_pkt_type_t type)
{
    const wifi_promiscuous_pkt_t *pkt = (const wifi_promiscuous_pkt_t *)buf;
    const wifi_pkt_rx_ctrl_t *rx = &pkt->rx_ctrl;

    frame_snap_t s;
    s.rssi      = rx->rssi;
    s.channel   = rx->channel;
    s.len       = rx->sig_len;
    s.timestamp = rx->timestamp;

    uint16_t n = (rx->sig_len < SNAP_MAX) ? rx->sig_len : SNAP_MAX;
    s.snap_len = n;
    memcpy(s.buf, pkt->payload, n);

    if (xQueueSend(g_frame_q, &s, 0) != pdTRUE) {
        drops++;   /* surface this on the display; sustained drops = too-slow consumer */
    }
}

static void hop_cb(void *arg)
{
    hop_idx = (hop_idx + 1) % (sizeof(channels) / sizeof(channels[0]));
    esp_wifi_set_channel(channels[hop_idx], WIFI_SECOND_CHAN_NONE);
}

esp_err_t capture_start(uint32_t dwell_ms)
{
    g_frame_q = xQueueCreate(64, sizeof(frame_snap_t));
    if (!g_frame_q) return ESP_ERR_NO_MEM;

    wifi_promiscuous_filter_t filt = {
        .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT |
                       WIFI_PROMIS_FILTER_MASK_DATA |
                       WIFI_PROMIS_FILTER_MASK_CTRL
    };
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous_filter(&filt));
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous_rx_cb(promisc_cb));
    ESP_ERROR_CHECK(esp_wifi_set_promiscuous(true));
    ESP_ERROR_CHECK(esp_wifi_set_channel(channels[0], WIFI_SECOND_CHAN_NONE));

    const esp_timer_create_args_t targs = {
        .callback = hop_cb,
        .name = "chanhop",
        .dispatch_method = ESP_TIMER_TASK,
    };
    ESP_ERROR_CHECK(esp_timer_create(&targs, &hop_timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(hop_timer, (uint64_t)dwell_ms * 1000));

    ESP_LOGI(TAG, "promiscuous up: all-frames, %u ch, dwell %u ms",
             (unsigned)(sizeof(channels)/sizeof(channels[0])), (unsigned)dwell_ms);
    return ESP_OK;
}
