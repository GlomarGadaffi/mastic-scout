#include "detect.h"
#include "frame_queue.h"
#include "ieee80211.h"
#include "alert.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include <string.h>
#include <stdbool.h>

static const char *TAG = "detect";

extern QueueHandle_t g_frame_q;

#ifndef SENSOR_ID
#define SENSOR_ID 1
#endif

/* ---- tunables ---------------------------------------------------------- */
#define WIN_US         1000000ULL
#define DEAUTH_THRESH  20
#define BEACON_THRESH  80
#define AUTH_THRESH    40

static uint64_t win_start;
static uint16_t ct_deauth, ct_beacon, ct_auth;

/* Single choke point: every signature funnels an alert_t into g_alert_q.
 * Non-blocking; if the uplink is backed up we drop the alert rather than
 * stall detection. (A lost alert is better than a missed attack.) */
static void emit(uint8_t sig, uint8_t ch, int8_t rssi, const uint8_t *src, uint16_t count)
{
    ESP_LOGW(TAG, "%-12s ch=%2u rssi=%4d n=%u", sig_name(sig), ch, rssi, count);
    if (!g_alert_q) return;
    alert_t a = {
        .magic = ALERT_MAGIC, .sensor_id = SENSOR_ID, .sig = sig,
        .channel = ch, .rssi = rssi, .count = count,
        .uptime_s = (uint32_t)(esp_timer_get_time() / 1000000ULL),
    };
    if (src) memcpy(a.src, src, 6);
    xQueueSend(g_alert_q, &a, 0);
}

static bool snap_is_eapol(const frame_snap_t *s)
{
    for (int i = 24; i + 8 <= s->snap_len; i++)
        if (s->buf[i]==0xAA && s->buf[i+1]==0xAA && s->buf[i+2]==0x03 &&
            s->buf[i+6]==0x88 && s->buf[i+7]==0x8E) return true;
    return false;
}

static void window_eval(void)
{
    if (ct_deauth >= DEAUTH_THRESH) emit(SIG_DEAUTH_FLOOD, 0, 0, NULL, ct_deauth);
    if (ct_beacon >= BEACON_THRESH) emit(SIG_BEACON_FLOOD, 0, 0, NULL, ct_beacon);
    if (ct_auth   >= AUTH_THRESH)   emit(SIG_AUTH_FLOOD,   0, 0, NULL, ct_auth);
    ct_deauth = ct_beacon = ct_auth = 0;
}

/* evil-twin: populate from your own APs (static or first-seen pinning). */
typedef struct { char ssid[33]; uint8_t bssid[6]; } known_ap_t;
static const known_ap_t known[] = { /* { "MyNet", {0xde,0xad,0xbe,0xef,0x00,0x01} }, */ };

static void check_beacon_evil_twin(const frame_snap_t *s)
{
    if (s->snap_len < 38) return;
    const uint8_t *t = s->buf + 36;          /* tagged params; tag0 = SSID */
    if (t[0] != 0) return;
    uint8_t len = t[1];
    if (len == 0 || len > 32 || 38 + len > s->snap_len) return;
    const uint8_t *bssid = s->buf + 16;      /* addr3 */
    for (size_t k = 0; k < sizeof(known)/sizeof(known[0]); k++)
        if ((size_t)len == strlen(known[k].ssid) &&
            strncmp((const char *)&t[2], known[k].ssid, len) == 0 &&
            memcmp(bssid, known[k].bssid, 6) != 0)
            emit(SIG_EVIL_TWIN, s->channel, s->rssi, s->buf + 10, 0);
}

void detect_task(void *arg)
{
    frame_snap_t s;
    win_start = esp_timer_get_time();
    for (;;) {
        if (xQueueReceive(g_frame_q, &s, pdMS_TO_TICKS(100)) == pdTRUE) {
            uint8_t type = fc_type(s.buf), sub = fc_subtype(s.buf);
            const uint8_t *src = s.buf + 10;
            if (type == WIFI_TYPE_MGMT) {
                switch (sub) {
                case MGMT_DEAUTH:
                case MGMT_DISASSOC: ct_deauth++; emit(SIG_DEAUTH, s.channel, s.rssi, src, 0); break;
                case MGMT_BEACON:   ct_beacon++; check_beacon_evil_twin(&s); break;
                case MGMT_AUTH:     ct_auth++; break;
                default: break;
                }
            } else if (type == WIFI_TYPE_DATA) {
                if (snap_is_eapol(&s)) emit(SIG_EAPOL, s.channel, s.rssi, src, 0);
            }
        }
        uint64_t now = esp_timer_get_time();
        if (now - win_start >= WIN_US) { window_eval(); win_start = now; }
    }
}
