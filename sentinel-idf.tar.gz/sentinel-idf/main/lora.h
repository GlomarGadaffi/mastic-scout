#pragma once
#include "esp_err.h"

/* Brings up SX1262 over a dedicated ESP-IDF SPI host (RadioLib + EspHal).
 * Call once before spawning the task below. */
esp_err_t lora_init(void);

/* ROLE_SENSOR: drains g_alert_q, transmits each alert_t.
 * ROLE_BASE:   receives alert_t frames, pushes them into g_alert_q for the UI.
 * Pick the right one in main.c per role. */
void lora_tx_task(void *arg);   /* sensor */
void lora_rx_task(void *arg);   /* base   */
