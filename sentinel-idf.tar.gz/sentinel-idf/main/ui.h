#pragma once
#include <stdint.h>

void ui_init(void);          /* OLED + motor (LEDC) bringup */
void ui_task(void *arg);     /* drains g_alert_q -> OLED line + haptic pattern */

/* Fire a haptic pattern directly (used by ui_task; exposed for self-test). */
void haptic(uint8_t sig);
