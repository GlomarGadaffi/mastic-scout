#pragma once
#include <stdint.h>
#include "esp_err.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"

extern QueueHandle_t g_frame_q;

/* Puts the radio into all-frames promiscuous mode and starts hopping.
 * dwell_ms = time parked on each channel before hopping. */
esp_err_t capture_start(uint32_t dwell_ms);
