#pragma once

/* Drains g_frame_q, classifies frames, runs signatures, emits alerts.
 * Pin to the core that is NOT running the WiFi driver. */
void detect_task(void *arg);
