#pragma once
#include <stdint.h>

/* 802.11 frame TYPE (bits 2-3 of FC byte 0) */
#define WIFI_TYPE_MGMT 0
#define WIFI_TYPE_CTRL 1
#define WIFI_TYPE_DATA 2

/* management SUBTYPE (bits 4-7 of FC byte 0) */
#define MGMT_ASSOC_REQ    0
#define MGMT_ASSOC_RESP   1
#define MGMT_REASSOC_REQ  2
#define MGMT_REASSOC_RESP 3
#define MGMT_PROBE_REQ    4
#define MGMT_PROBE_RESP   5
#define MGMT_BEACON       8
#define MGMT_DISASSOC     10
#define MGMT_AUTH         11
#define MGMT_DEAUTH       12

/* control SUBTYPE */
#define CTRL_RTS          11
#define CTRL_CTS          12
#define CTRL_ACK          13

/* Generic MAC header. addr3 is BSSID for most management frames. Note QoS
 * data frames carry an extra 2-byte QoS control field after this, and 4-addr
 * frames an extra addr4 — the EAPOL scanner below tolerates that by searching
 * for the SNAP signature rather than trusting a fixed offset. */
typedef struct __attribute__((packed)) {
    uint8_t  fc_byte0;     /* protocol ver(2) | type(2) | subtype(4) */
    uint8_t  fc_byte1;     /* toDS fromDS moreFrag retry pwr more wep order */
    uint16_t duration;
    uint8_t  addr1[6];     /* RA / DA   */
    uint8_t  addr2[6];     /* TA / SA   <- the transmitter; this is your suspect */
    uint8_t  addr3[6];     /* BSSID     */
    uint16_t seq_ctrl;
} ieee80211_hdr_t;

static inline uint8_t fc_type(const uint8_t *p)    { return (p[0] >> 2) & 0x03; }
static inline uint8_t fc_subtype(const uint8_t *p) { return (p[0] >> 4) & 0x0F; }
