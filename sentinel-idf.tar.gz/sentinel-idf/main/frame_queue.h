#pragma once
#include <stdint.h>

/* Bytes copied out of each frame in the RX callback. Big enough for the MAC
 * header + beacon fixed params + start of tagged params (SSID) + the LLC/SNAP
 * + EAPOL ethertype region. We never need full payloads for detection, and
 * keeping this bounded is what keeps the callback non-blocking. */
#define SNAP_MAX 160

typedef struct {
    int8_t   rssi;        /* dBm, from rx_ctrl */
    uint8_t  channel;     /* channel frame was heard on */
    uint16_t len;         /* full on-air frame length (rx_ctrl.sig_len) */
    uint16_t snap_len;    /* bytes actually copied into buf */
    uint32_t timestamp;   /* rx_ctrl.timestamp, microseconds */
    uint8_t  buf[SNAP_MAX];
} frame_snap_t;
